package ru.edu.pr04;
public final class Product {
    private final String id;
    private final String name;
    private final double price;

    public Product(String id, String name, double price) {
        if (id == null || id.isBlank() || name == null || name.isBlank()) {
            throw new IllegalArgumentException("Код и название товара обязательны");
        }
        if (!Double.isFinite(price) || price <= 0) {
            throw new IllegalArgumentException("Цена должна быть положительным конечным числом");
        }
        this.id = id.strip();
        this.name = name.strip();
        this.price = price;
    }

    public String getId() { return id; }
    public String getName() { return name; }
    public double getPrice() { return price; }
}
