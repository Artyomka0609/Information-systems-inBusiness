package ru.edu.pr04;

import java.nio.charset.StandardCharsets;
import java.util.Scanner;

public final class OrderService {
    // Вариант 8: максимальная сумма подтверждаемого заказа, граница включена.
    public static final double MAX_TOTAL = 45.0;

    public Order createOrder(Employee employee) {
        return new Order(employee);
    }

    public static void validateForConfirm(Order order) {
        if (order == null) throw new IllegalArgumentException("Заказ не задан");
        if (order.getStatus() != OrderStatus.DRAFT) {
            throw new IllegalStateException("Заказ уже подтверждён");
        }
        if (order.getItems().isEmpty()) {
            throw new IllegalStateException("Пустой заказ подтвердить нельзя");
        }
        double amount = order.total();
        if (!Double.isFinite(amount) || amount > MAX_TOTAL) {
            throw new IllegalStateException("Сумма заказа превышает лимит " + MAX_TOTAL);
        }
    }

    static void addRow(Order order, String row) {
        if (row == null || row.isBlank()) throw new IllegalArgumentException("Строка товара пуста");
        String[] fields = row.split(";", -1);
        if (fields.length != 4) {
            throw new IllegalArgumentException("Ожидаются id;название;цена;количество");
        }
        try {
            double price = Double.parseDouble(fields[2].strip());
            int quantity = Integer.parseInt(fields[3].strip());
            order.addProduct(new Product(fields[0], fields[1], price), quantity);
        } catch (NumberFormatException exception) {
            throw new IllegalArgumentException("Цена должна быть числом, количество — целым числом");
        }
    }

    private static void printOrder(Order order) {
        System.out.println("Сотрудник: " + order.getEmployee().id() + "; " + order.getEmployee().fullName());
        for (OrderItem item : order.getItems()) {
            Product product = item.getProduct();
            System.out.println(product.getId() + "; " + product.getName() + "; "
                    + product.getPrice() + " x " + item.getQuantity() + " = " + item.getLineTotal());
        }
        System.out.println("Итого: " + order.total() + "; статус: " + order.getStatus());
    }

    public static void main(String[] args) {
        try (Scanner input = new Scanner(System.in, StandardCharsets.UTF_8)) {
            System.out.println("Введите код сотрудника:");
            if (!input.hasNextLine()) return;
            String id = input.nextLine();
            System.out.println("Введите ФИО сотрудника:");
            if (!input.hasNextLine()) return;
            Order order = new OrderService().createOrder(new Employee(id, input.nextLine()));
            System.out.println("Команды: add;id;название;цена;количество | remove;id | show | confirm | exit");
            while (input.hasNextLine()) {
                String command = input.nextLine().strip();
                try {
                    if (command.equals("exit")) return;
                    if (command.startsWith("add;")) {
                        addRow(order, command.substring(4));
                    } else if (command.startsWith("remove;")) {
                        order.removeProduct(command.substring(7));
                    } else if (command.equals("show")) {
                        printOrder(order);
                    } else if (command.equals("confirm")) {
                        order.confirm();
                        System.out.println("Заказ подтверждён");
                    } else {
                        throw new IllegalArgumentException("Неизвестная команда");
                    }
                } catch (IllegalArgumentException | IllegalStateException exception) {
                    System.out.println("Ошибка: " + exception.getMessage());
                }
            }
        } catch (IllegalArgumentException exception) {
            System.out.println("Ошибка: " + exception.getMessage());
        }
    }
}
