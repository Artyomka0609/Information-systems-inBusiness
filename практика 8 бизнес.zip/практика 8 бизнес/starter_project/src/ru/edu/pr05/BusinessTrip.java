package ru.edu.pr05;

import java.io.BufferedReader;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class BusinessTrip {
    private static final int MIN_REASON_LENGTH = 10;
    // Принятое правило варианта 8: минимум 45 дней до начала поездки.
    private static final int MIN_CANCEL_DAYS = 45;
    private final String id;
    private Employee employee;
    private final LocalDate start;
    private final LocalDate end;
    private TripStatus status = TripStatus.DRAFT;
    private String rejectionReason;

    public BusinessTrip(String id, LocalDate start, LocalDate end) {
        if (id == null || id.trim().isEmpty()) {
            throw new IllegalArgumentException("Идентификатор обязателен");
        }
        if (start == null || end == null) {
            throw new IllegalArgumentException("Даты начала и окончания обязательны");
        }
        if (end.isBefore(start)) {
            throw new IllegalArgumentException("Окончание раньше начала");
        }
        this.id = id;
        this.start = start;
        this.end = end;
    }

    private void requireStatus(TripStatus required) {
        if (status != required) {
            throw new IllegalStateException("Требуется " + required + ", текущий статус " + status);
        }
    }

    public void submit() {
        requireStatus(TripStatus.DRAFT);
        // Обязательные поля проверены конструктором и не изменяются.
        status = TripStatus.SUBMITTED;
    }

    public void approve() {
        requireStatus(TripStatus.SUBMITTED);
        status = TripStatus.APPROVED;
    }

    public void reject(String reason) {
        requireStatus(TripStatus.SUBMITTED);
        if (reason == null || reason.trim().isEmpty() || reason.length() < MIN_REASON_LENGTH) {
            throw new IllegalArgumentException("Причина обязательна и содержит минимум 10 символов");
        }
        rejectionReason = reason;
        status = TripStatus.REJECTED;
    }

    public void cancel() {
        cancel(LocalDate.now());
    }

    public void cancel(LocalDate today) {
        if (status != TripStatus.DRAFT && status != TripStatus.SUBMITTED
                && status != TripStatus.APPROVED) {
            throw new IllegalStateException("Отмена недоступна из " + status);
        }
        if (today == null) {
            throw new IllegalArgumentException("Текущая дата обязательна");
        }
        if (ChronoUnit.DAYS.between(today, start) < MIN_CANCEL_DAYS) {
            throw new IllegalArgumentException("Для отмены до начала поездки должно оставаться не менее "
                    + MIN_CANCEL_DAYS + " календарных дней");
        }
        status = TripStatus.CANCELLED;
    }

    public void complete(LocalDate today) {
        requireStatus(TripStatus.APPROVED);
        if (today == null) {
            throw new IllegalArgumentException("Текущая дата обязательна");
        }
        if (!today.isAfter(end)) {
            throw new IllegalArgumentException("Завершение допустимо только после " + end);
        }
        status = TripStatus.COMPLETED;
    }

    public TripStatus getStatus() { return status; }
    public String getRejectionReason() { return rejectionReason; }
}

class BusinessTripService {
    private final List<BusinessTrip> trips = new ArrayList<BusinessTrip>();

    public BusinessTrip create(String id, LocalDate start, LocalDate end) {
        BusinessTrip trip = new BusinessTrip(id, start, end);
        trips.add(trip);
        return trip;
    }

    public List<BusinessTrip> findByStatus(TripStatus status) {
        if (status == null) {
            throw new IllegalArgumentException("Статус обязателен");
        }
        List<BusinessTrip> result = new ArrayList<BusinessTrip>();
        for (BusinessTrip trip : trips) {
            if (trip.getStatus() == status) { result.add(trip); }
        }
        return result;
    }
}

// Тип указан в исходной диаграмме; его поля и операции в задании не определены.
class Employee {
}

class Application {
    private final BusinessTripService service = new BusinessTripService();

    public static LocalDate parseDate(String value) {
        if (value == null || value.isEmpty()) {
            throw new IllegalArgumentException("Дата обязательна");
        }
        try {
            return LocalDate.parse(value);
        } catch (DateTimeParseException ex) {
            throw new IllegalArgumentException("Неверная календарная дата: " + value, ex);
        }
    }

    private void execute(BusinessTrip trip, String action, String reason, LocalDate today) {
        switch (action) {
            case "SUBMIT": trip.submit(); break;
            case "APPROVE": trip.approve(); break;
            case "REJECT": trip.reject(reason); break;
            case "CANCEL": trip.cancel(today); break;
            case "COMPLETE": trip.complete(today); break;
            default: throw new IllegalArgumentException("Неизвестная команда: " + action);
        }
    }

    public void readSample(Path path) throws IOException {
        try (BufferedReader reader = Files.newBufferedReader(path, StandardCharsets.UTF_8)) {
            if (!"id;start;end;action".equals(reader.readLine())) {
                throw new IllegalArgumentException("Ожидается заголовок id;start;end;action");
            }
            String line;
            int number = 1;
            while ((line = reader.readLine()) != null) {
                number++;
                try {
                    String[] fields = line.split(";", -1);
                    if (fields.length != 4) {
                        throw new IllegalArgumentException("Ожидаются четыре поля");
                    }
                    BusinessTrip trip = service.create(fields[0], parseDate(fields[1]), parseDate(fields[2]));
                    execute(trip, fields[3], null, LocalDate.now());
                    System.out.println("Строка " + number + ": " + trip.getStatus());
                } catch (IllegalArgumentException | IllegalStateException ex) {
                    System.out.println("Строка " + number + ": " + ex.getClass().getSimpleName()
                            + ": " + ex.getMessage());
                }
            }
        }
    }

    public void run(Scanner input) {
        System.out.println("Идентификатор:");
        String id = input.nextLine();
        System.out.println("Дата начала (ГГГГ-ММ-ДД):");
        LocalDate start = parseDate(input.nextLine());
        System.out.println("Дата окончания (ГГГГ-ММ-ДД):");
        LocalDate end = parseDate(input.nextLine());
        BusinessTrip trip = service.create(id, start, end);
        System.out.println(trip.getStatus());
        while (true) {
            System.out.println("Команда SUBMIT, APPROVE, REJECT, CANCEL, COMPLETE; пустая строка - выход:");
            if (!input.hasNextLine()) { return; }
            String action = input.nextLine();
            if (action.isEmpty()) { return; }
            try {
                String reason = null;
                LocalDate today = null;
                if ("REJECT".equals(action)) {
                    System.out.println("Причина отклонения:");
                    reason = input.nextLine();
                }
                if ("CANCEL".equals(action) || "COMPLETE".equals(action)) {
                    System.out.println("Текущая дата (ГГГГ-ММ-ДД):");
                    today = parseDate(input.nextLine());
                }
                execute(trip, action, reason, today);
                System.out.println(trip.getStatus());
            } catch (IllegalArgumentException | IllegalStateException ex) {
                System.out.println(ex.getClass().getSimpleName() + ": " + ex.getMessage());
            }
        }
    }

    public static void main(String[] args) {
        Application app = new Application();
        try {
            if (args.length == 0) {
                app.run(new Scanner(System.in, "UTF-8"));
            } else if (args.length == 1) {
                app.readSample(Paths.get(args[0]));
            } else {
                throw new IllegalArgumentException("Передайте один путь к CSV или запускайте без аргументов");
            }
        } catch (IOException | IllegalArgumentException | java.util.NoSuchElementException ex) {
            System.err.println("Ошибка: " + ex.getMessage());
            System.exit(1);
        }
    }
}
