package ru.edu.pr03;

public class SelfCheck {
    private static int passed;
    private static int failed;

    public static void main(String[] args) {
        ApprovalRouter router = new ApprovalRouter();
        long limit = ApprovalRouter.FINANCE_LIMIT;
        check("zero", router.route(0, true, RiskLevel.LOW, false)
                == ApprovalRoute.FAST_TRACK);
        check("below limit", router.route(limit - 1, true, RiskLevel.LOW, false)
                == ApprovalRoute.FAST_TRACK);
        check("exact limit", router.route(limit, true, RiskLevel.LOW, false)
                == ApprovalRoute.FINANCE_REVIEW);
        check("above limit", router.route(limit + 1, false, RiskLevel.LOW, false)
                == ApprovalRoute.FINANCE_REVIEW);
        check("high risk", router.route(100, true, RiskLevel.HIGH, false)
                == ApprovalRoute.DIRECTOR_REVIEW);
        check("personal data", router.route(100, true, RiskLevel.LOW, true)
                == ApprovalRoute.SECURITY_REVIEW);
        check("all conditions", router.route(limit + 1, true, RiskLevel.HIGH, true)
                == ApprovalRoute.SECURITY_REVIEW);
        check("standard", router.route(100, false, RiskLevel.MEDIUM, false)
                == ApprovalRoute.STANDARD);
        check("risk beats finance", router.route(limit, true, RiskLevel.HIGH, false)
                == ApprovalRoute.DIRECTOR_REVIEW);
        check("CSV values", router.parseLine("100;TRUE;low;false")
                == ApprovalRoute.FAST_TRACK);

        expectError("negative amount", "-1;false;LOW;false");
        expectError("empty amount", ";false;LOW;false");
        expectError("invalid amount", "abc;false;LOW;false");
        expectError("overflow", "9223372036854775808;false;LOW;false");
        expectError("invalid boolean", "100;yes;LOW;false");
        expectError("invalid risk", "100;false;UNKNOWN;false");
        expectError("empty personal", "100;false;LOW;");
        expectError("missing field", "100;false;LOW");
        System.out.println("RESULT: " + passed + " passed, " + failed + " failed");
        if (failed > 0) System.exit(1);
    }

    private static void expectError(String name, String line) {
        try {
            new ApprovalRouter().parseLine(line);
            check(name, false);
        } catch (IllegalArgumentException expected) {
            check(name, true);
        }
    }

    private static void check(String name, boolean condition) {
        if (condition) passed++; else failed++;
        System.out.println((condition ? "PASS " : "FAIL ") + name);
    }
}
