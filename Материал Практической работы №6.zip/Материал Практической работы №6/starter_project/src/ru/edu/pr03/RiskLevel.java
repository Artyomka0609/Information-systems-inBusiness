package ru.edu.pr03;

/** Допустимые уровни риска; неизвестное значение не заменяется на LOW. */
public enum RiskLevel {
    LOW, MEDIUM, HIGH
}
