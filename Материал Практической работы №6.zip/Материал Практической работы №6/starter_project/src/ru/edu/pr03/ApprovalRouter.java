package ru.edu.pr03;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;
import java.util.Locale;

public class ApprovalRouter {
    public static final long FINANCE_LIMIT = 500_000L;

    public ApprovalRoute route(long amount, boolean urgent, RiskLevel risk,
                               boolean containsPersonalData) {
        if (amount < 0) throw new IllegalArgumentException("amount must be non-negative");
        if (risk == null) throw new IllegalArgumentException("risk is required");

        if (containsPersonalData) {
            return ApprovalRoute.SECURITY_REVIEW;
        } else if (requiresDirector(risk)) {
            return resolveRiskAndFinance(amount);
        } else if (requiresFinance(amount)) {
            return ApprovalRoute.FINANCE_REVIEW;
        } else if (urgent) {
            return ApprovalRoute.FAST_TRACK;
        } else {
            return ApprovalRoute.STANDARD;
        }
    }

    private boolean requiresDirector(RiskLevel risk) {
        switch (risk) {
            case HIGH: return true;
            default: return false;
        }
    }

    private boolean requiresFinance(long amount) {
        return amount >= FINANCE_LIMIT;
    }

    private ApprovalRoute resolveRiskAndFinance(long amount) {
        // Вариант 8: вес риска 45, финансов 40. При равенстве важнее риск.
        if (requiresFinance(amount) && ApprovalRoute.FINANCE_REVIEW.getPriority()
                > ApprovalRoute.DIRECTOR_REVIEW.getPriority()) {
            return ApprovalRoute.FINANCE_REVIEW;
        }
        return ApprovalRoute.DIRECTOR_REVIEW;
    }

    public static void main(String[] args) {
        if (args.length > 1) {
            System.err.println("Usage: ApprovalRouter [file.csv]");
            System.exit(2);
        }
        try {
            new ApprovalRouter().processCsv(args.length == 0 ? "data/sample.csv" : args[0]);
        } catch (IOException | IllegalArgumentException e) {
            System.err.println("ERROR: " + e.getMessage());
            System.exit(2);
        }
    }

    private void processCsv(String file) throws IOException {
        List<String> lines = Files.readAllLines(Paths.get(file), StandardCharsets.UTF_8);
        if (lines.isEmpty() || !lines.get(0).replace("\uFEFF", "").trim()
                .equals("amount;urgent;risk;personal")) {
            throw new IllegalArgumentException("expected header: amount;urgent;risk;personal");
        }
        if (lines.size() == 1) throw new IllegalArgumentException("CSV contains no requests");
        System.out.println("line;route");
        boolean hasErrors = false;
        for (int i = 1; i < lines.size(); i++) {
            try {
                System.out.println((i + 1) + ";" + parseLine(lines.get(i)));
            } catch (IllegalArgumentException e) {
                hasErrors = true;
                System.err.println("ERROR line " + (i + 1) + ": " + e.getMessage());
            }
        }
        if (hasErrors) System.exit(1);
    }

    ApprovalRoute parseLine(String line) {
        String[] fields = line.split(";", -1); // Сохраняем пустое последнее поле.
        if (fields.length != 4) throw new IllegalArgumentException("expected 4 fields");
        return route(parseAmount(fields[0]), parseBoolean(fields[1], "urgent"),
                parseRisk(fields[2]), parseBoolean(fields[3], "personal"));
    }

    public static long parseAmount(String text) {
        String value = required(text, "amount");
        if (!value.matches("[0-9]+")) {
            throw new IllegalArgumentException("amount must be a non-negative integer");
        }
        return Long.parseLong(value);
    }

    public static boolean parseBoolean(String text, String field) {
        String value = required(text, field);
        if ("true".equalsIgnoreCase(value)) return true;
        if ("false".equalsIgnoreCase(value)) return false;
        throw new IllegalArgumentException(field + " must be true or false");
    }

    public static RiskLevel parseRisk(String text) {
        return RiskLevel.valueOf(required(text, "risk").toUpperCase(Locale.ROOT));
    }

    private static String required(String text, String field) {
        if (text == null || text.trim().isEmpty()) {
            throw new IllegalArgumentException(field + " is required");
        }
        return text.trim();
    }
}
